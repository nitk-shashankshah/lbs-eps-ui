export const environment = {
  production: true,
  server: '10.150.76.45'
};